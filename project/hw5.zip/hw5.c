


/**************************************************************
 *Author Bryan Konshak   5/14/2018		Algorithms
 * ************************************************************************/
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
//#include <algorithm>
//#include<bits/stdc++.h>
//using namespace std;

void error(const char *msg) { perror(msg); exit(0); } // Error function used for reporting issues
struct wrestler{
	char *name;
	//	string name;
	int bad ;

};
/*main function pulls lines from file and parses them into wrestler arrays*/
int main(int argc, char* argv[])
{
	if (argc != 2) { fprintf(stderr,"USAGE: %s filename\n", argv[0]); exit(0); } // Check usage & args
	FILE* fp = fopen(argv[1], "r");

	char arr[10000];
	char*ptr;
	int isn = 1;
	int wrestle=1;
	int n ;
	int i = 0;
	int j = 0;
	//	int K = 500;
	int m = 0;
	int p = 0;
	//	vector<int> graph[5];
	char edgeOne[1000];
	int vone;
	int vtwo;
	char edgeTwo[1000];
	char copies[1000];
	Graph* graphs;
	Vertex* vertex ;
	int result;
	if(fp)
	{
		char strings[1000][1000];
		//	wrestlers2[0].bad=1;
		while ((ptr= fgets(arr, sizeof arr, fp)) !=NULL) //read each line
		{
			ptr = strtok(arr , " ");
			while(ptr)
			{
				if(isn)
				{
					n = strtol(ptr, NULL, 10);//n values
					//printf("N:  %d \n", n);
					ptr = strtok(NULL, " ");
					isn=0;
				}
				else
				{
					if(wrestle)//create array of wrestler names
					{
						char *pos;

						strcpy(copies, ptr);
						strcpy(strings[j],copies);//array string
						if((pos=strchr(strings[j], '\n')) != NULL)//strip in
							*pos = '\0';
						j++;
						ptr = strtok(NULL, " ");
					}
					else
					{
						if(m%2==0)//first of rivalry//numbers used to index the vertices
						{
							strcpy(edgeOne, ptr);//copy to first vertex for edge
							//						cout << edgeOne << strings[0]<<strings[1]<<strings[2] << "test" << endl;
							for(p=0;p<n;p++)
							{

								if(strcmp(edgeOne, strings[p])==0)
								{
									vone=p;
			//						printf("%d vone\n", vone);
									break;
								}
							}
						}
						else if(m%2==1)  //copy second vertex
						{
							//			edgeTwo = ptr;
							char *pos;			
							strcpy(edgeTwo, ptr);
			//				printf("%s \n", edgeTwo);
							if((pos=strchr(edgeTwo, '\n')) != NULL)
								*pos = '\0';
							for(p=0;p<result;p++)
							{

								//							cout <<"hi there! "<< edgeTwo << "   " << strings[p] << "  again p"<< p <<endl;
								//if(edgeTwo==strings[p])
								if(strcmp(edgeTwo, strings[p])==0)
								{
									vtwo=p;
							//		printf("%d vtwo\n", vtwo);
									break;
								}
							}
			//				printf("%d i \n", i);
						//	printf("Creating the graph: %d, %d  ", vone, vtwo);
							createEdge(&graphs->vertexSet[vone], &graphs->vertexSet[vtwo]);//edge function added to graph
							if(i==n && wrestle==0)
							{
			//					printGraph(graphs);
							}
							//createEdge(vertex, vertex);
							//				add(wrestlers, edgeOne, edgeTwo);
						}
						m++;
						//printf("m: %d\n", m);

						//		printf(" %s", ptr);
						ptr = strtok(NULL, " ");
					}

				}



			}
			i++;
		//	printf("wrestle %d\n,", wrestle);
			if(i==n+1&&wrestle==1)//transition from wresters to rivalry
			{
				result = n;//save for function
				//		printf("%s right here, ", strings[0]);
				graphs=initGraph(strings, n);
				vertex = &graphs->vertexSet[0];
				i=0;
				isn=1;
				wrestle=0;//skip wrestle logic above
			}
		}
		int testing;
		//printf("Result: %d", result);
		int good[100];
		int bad[100];
		//	int goodInt=0;
		//	int badInt=0;
		int goodbad[5];
		testing =bfsIteratived(graphs, &graphs->vertexSet[0], &graphs->vertexSet[result-1], good, bad, goodbad, result);//program to find rivalries
		//printf("\n%d should be 1\n", testing);
		//	printf("%d right here, ", goodbad[0]);
		if(testing)//if return true then not possible
			printf("\nNo\nImpossible\n");
		else
		{

			printf("\nYes\n");
			printf("Babyfaces: ");
			for (i=0; i< goodbad[0];i++)
			{
				printf("%s ", strings[good[i]]);
			}
			printf("\nHeals: ");
			for (i=0; i< goodbad[1];i++)
			{
				printf("%s ", strings[bad[i]]);
			}

			printf("\n");
		}
		free(graphs);


	}
	else{printf("File does not exist\n");}
}


